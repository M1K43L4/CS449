package com.example.pitchdetect;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.pm.PackageManager;
import android.os.Bundle;

import be.tarsos.dsp.AudioDispatcher;
import android.widget.TextView;
import android.widget.Toast;

import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;


import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;


public class MainActivity extends AppCompatActivity {

    public static final int MY_PERMISSIONS_CODE = 1;

    public TextView pitchN;
    public TextView hertzV;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //START --------------------------------------------------------------
        pitchN = findViewById(R.id.pitch);
        hertzV = findViewById(R.id.hertz);
        AudioDispatcher dispatcher;

        // PERMISSIONS
        if(checkPermission()){
            // continue -------------- ALLOW CHECKING AUDIO
        }
        else{
            requestPermission();
        }


        // PITCH DETECTION HANDLER -------------------------------------------------------------

        PitchDetectionHandler PITCH_DETECTION_HANDLER = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e){
                final float pitch_hertz = res.getPitch();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        processPitch(pitch_hertz);
                    }
                });
            }
        };


        dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050,1024,0);


        // FINAL STEP -------------------------------------------------------------------
        AudioProcessor pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, PITCH_DETECTION_HANDLER);
        dispatcher.addAudioProcessor(pitchProcessor);

        Thread audioThread = new Thread(dispatcher, "Audio Thread");
        audioThread.start();

    }

    // PROCESS NOTE ------------------------- Frequencies for equal-tempered scale
    public double processNote(int half_steps){
        double frequency_of_note_n_half_steps_away = -1;
        float frequency_of_fixed_note = 440;  // A4... the A after C4
        double a  = Math.pow(2,(1/12));
        frequency_of_note_n_half_steps_away = frequency_of_fixed_note * Math.pow(a, half_steps);

        return frequency_of_note_n_half_steps_away;
    }

    // PROCESS Octave -------------------------
    public int processOctave(float my_hertz){
        int octave= -1; // default
        int octave_half_steps = 12;

        if (my_hertz >= (processNote(octave_half_steps*(-4))-10)){
            octave = 0; // this is the lowest we'll go; half steps is -48 from A4 -- 4 octaves below
        }

        return octave;
    }

    // PROCESS PITCH ------------------------------------------------------------
    public void processPitch(float pitch_hertz) {

        hertzV.setText("" + pitch_hertz);
        pitchN.setText("YOUR NOTE");  // default

        // START ASSIGNING PITCH VALUES TO NOTES AND OCTAVES ----------------------------------------
        if(pitch_hertz >= (processNote(0)-2)){
            pitchN.setText("A" + processOctave(pitch_hertz));
        }

    }




    // PERMISSION FUNCTIONS BELOW -------------------------------------------------

    private void requestPermission() {

        ActivityCompat.requestPermissions(MainActivity.this, new String[]{WRITE_EXTERNAL_STORAGE, RECORD_AUDIO},
                MY_PERMISSIONS_CODE);

    }

    public void onRequestPermissionsResult(int request_permissions_code, String permissions[], int[] show_results) {

        switch (request_permissions_code) {

            case MY_PERMISSIONS_CODE:

                if (show_results.length> 0) {

                    boolean storage_permission = show_results[0] ==
                            PackageManager.PERMISSION_GRANTED;
                    boolean record_audio_permission = show_results[1] ==
                            PackageManager.PERMISSION_GRANTED;

                    if (storage_permission && record_audio_permission) {

                        Toast.makeText(MainActivity.this, "Permission Granted", Toast.LENGTH_LONG).show();

                    } else {

                        Toast.makeText(MainActivity.this,"Permission Denied",Toast.LENGTH_LONG).show();

                    }

                }

                break;

        }

    }


    public boolean checkPermission() {

        int storage_result = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int audio_result = ContextCompat.checkSelfPermission(getApplicationContext(), RECORD_AUDIO);
        return storage_result == PackageManager.PERMISSION_GRANTED && audio_result == PackageManager.PERMISSION_GRANTED;

    }

}
