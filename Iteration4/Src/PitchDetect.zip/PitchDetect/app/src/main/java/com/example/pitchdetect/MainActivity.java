package com.example.pitchdetect;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import be.tarsos.dsp.AudioDispatcher;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.view.View;
import android.widget.Button;

import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.io.PipedAudioStream;
import be.tarsos.dsp.io.TarsosDSPAudioFormat;
import be.tarsos.dsp.io.TarsosDSPAudioInputStream;
import be.tarsos.dsp.io.android.AndroidAudioInputStream;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;


public class MainActivity extends AppCompatActivity {

    AudioDispatcher dispatcher;
    Button startButton;
    Button stopButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //START!!!!!!!!!!!!!!!!!!!!!!!

        startButton = findViewById(R.id.start);
        stopButton = findViewById(R.id.stop);
        //THESE MUST BE FINAL INTS OTHERWISE ERROR!!!!!!!!!!!
        final int sampleRate = 8000;
        final int audioBufferSize = 1024;
        final int bufferOverlap = 0;

        // will try to manually access microphone
        //SETTINGS
        //AudioDispatcher dispatcher;

        //FUNCTIONALITY

        //WORKS
        int minAudioBufferSize = AudioRecord.getMinBufferSize(sampleRate,
                android.media.AudioFormat.CHANNEL_IN_MONO,
                android.media.AudioFormat.ENCODING_PCM_16BIT);

        //WORKS
        int minAudioBufferSizeInSamples =  minAudioBufferSize/2;

        //WORKS - ERROR INSIDE
        if(minAudioBufferSizeInSamples <= audioBufferSize ){

            //WORKS
            AudioRecord audioInputStream = new AudioRecord(
                    MediaRecorder.AudioSource.MIC, sampleRate,
                    android.media.AudioFormat.CHANNEL_IN_MONO,
                    android.media.AudioFormat.ENCODING_PCM_16BIT,
                    audioBufferSize * 2);

            //WORKS
            TarsosDSPAudioFormat format = new TarsosDSPAudioFormat(sampleRate, 16,1, true, false);

            //ERROR IS HERE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! AUDIO RECORD MODULE
            //audioInputStream.startRecording();

            //WORKS
            TarsosDSPAudioInputStream audioStream = new AndroidAudioInputStream(audioInputStream, format);

            //WORKS
            dispatcher = new AudioDispatcher(audioStream,audioBufferSize,bufferOverlap);

        }
    }

    public void startRecording(View view){
        startButton.setEnabled(false);
        stopButton.setEnabled(true);
    }
    public void stopRecording(View view){
        stopButton.setEnabled(false);
        startButton.setEnabled(true);
    }


}
