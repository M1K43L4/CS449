package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Integer balls = 0;
    Integer strikes = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button exitButton = (Button) findViewById(R.id.exitButton);
        exitButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    public void addoneBall(View v){
        balls+=1;
        TextView t = (TextView) findViewById(R.id.ballsCount);
        t.setText(balls+"");
    }
    public void addoneStrike(View v){
        strikes+=1;
        TextView t = (TextView) findViewById(R.id.strikesCount);
        t.setText(strikes+"");
    }
    public void resetCount(View v){
        strikes=0;
        balls=0;
        TextView t = (TextView) findViewById(R.id.strikesCount);
        t.setText(strikes+"");
        t = (TextView) findViewById(R.id.ballsCount);
        t.setText(balls+"");
    }
}
