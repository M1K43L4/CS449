package com.example.lab1;


import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Pop extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popwindow);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String complete= extras.getString("EXTRA");
            TextView t = (TextView) findViewById(R.id.popWindow);
            t.setText(complete);
            //The key argument here must match that used in the other activity
        }





        /*
        if (check>=3) {
            TextView t = (TextView) findViewById(R.id.popWindow);
            t.setText("Max Strikes");


        }
        else {
            check = R.id.ballsCount;
            if (check >= 4) {
                TextView t = (TextView) findViewById(R.id.popWindow);
                t.setText("Max Balls");

            }
        }

         */


    }


}
