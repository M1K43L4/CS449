package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    //Global Variables
    Integer balls = 0;
    Integer strikes = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        //Exit Button
        Button exitButton = (Button) findViewById(R.id.exitButton);
        exitButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //About Button
        Button popupButton = (Button) findViewById(R.id.popupButton);
        popupButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v){
                startActivity(new Intent(MainActivity.this,Pop.class));
            }
        });
    }
    public void addoneBall(View v){
        balls+=1;
        if (balls>=4) {
            //resetCount(v);
            String walk = "WALK!";
            Intent i = new Intent(MainActivity.this, Pop.class);
            i.putExtra("EXTRA", walk);
            startActivity(i);


            //startActivity(new Intent(MainActivity.this, Pop.class));

            Button ballButton = (Button) findViewById(R.id.ballButton);
            Button strikeButton = (Button) findViewById(R.id.strikeButton);
            ballButton.setEnabled(false);
            strikeButton.setEnabled(false);
        }

        TextView t = (TextView) findViewById(R.id.ballsCount);
        t.setText(balls+"");
    }
    public void addoneStrike(View v){
        strikes+=1;
        if (strikes>=3) {
            //resetCount(v);
            String out = "OUT!";
            Intent i = new Intent(MainActivity.this, Pop.class);
            i.putExtra("EXTRA", out);
            startActivity(i);
            //startActivity(new Intent(MainActivity.this, Pop.class));

            Button ballButton = (Button) findViewById(R.id.ballButton);
            Button strikeButton = (Button) findViewById(R.id.strikeButton);
            ballButton.setEnabled(false);
            strikeButton.setEnabled(false);

        }
        TextView t = (TextView) findViewById(R.id.strikesCount);
        t.setText(strikes+"");
    }
    public void resetCount(View v){
        strikes=0;
        balls=0;
        Button ballButton = (Button) findViewById(R.id.ballButton);
        Button strikeButton = (Button) findViewById(R.id.strikeButton);
        ballButton.setEnabled(true);
        strikeButton.setEnabled(true);

        TextView t = (TextView) findViewById(R.id.strikesCount);
        t.setText(strikes+"");
        t = (TextView) findViewById(R.id.ballsCount);
        t.setText(balls+"");
    }
}
