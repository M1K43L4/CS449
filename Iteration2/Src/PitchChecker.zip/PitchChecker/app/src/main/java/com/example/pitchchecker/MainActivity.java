package com.example.pitchchecker;

//comes with
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

//need buttons for control
import android.widget.Button;

//for audio for control
import android.media.MediaPlayer;
import android.media.MediaRecorder;

//for display, storage, and error checks
import android.os.Environment;
import android.widget.Toast;
import java.io.IOException;
import java.util.Random;




public class MainActivity extends AppCompatActivity {

    //buttons for control
    Button StartRecording;
    Button StopRecording;
    Button PlayAudio;
    Button StopPlayingAudio;

    //variables for storing the audio
    String AudioStorage = null;//save location in device
    //will ensure each file is different
    Random random ;
    String AudioFile = "ABCDEFGHIJKLMNOP";

    //control variables
    MediaRecorder mediaRecorder ;
    MediaPlayer mediaPlayer ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);// connect to activity_main

        //Buttons
        StartRecording = (Button) findViewById(R.id.startButton);
        StopRecording = (Button) findViewById(R.id.stopButton);
        PlayAudio = (Button) findViewById(R.id.playButton);
        StopPlayingAudio = (Button)findViewById(R.id.stopPlayButton);

        //keep buttons from being used unless it makes sense to use them
        // only recording button should be enabled at start
        StopRecording.setEnabled(false);
        PlayAudio.setEnabled(false);
        StopPlayingAudio.setEnabled(false);

        //needed for storage
        random = new Random();

        StartRecording.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    //where to store audio
                    AudioStorage = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" +
                            MakeFileName(5) + "AudioRecording.3gp";

                    //prepare recorder on click
                    RecorderReady();
                    try {
                        mediaRecorder.prepare();
                        mediaRecorder.start();
                    } catch (IllegalStateException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    //switch button usability once recording has started
                    StartRecording.setEnabled(false);
                    StopRecording.setEnabled(true);

                    //inform user of success
                    Toast.makeText(MainActivity.this, "Recording Start",
                            Toast.LENGTH_LONG).show();
            }
        });

        StopRecording.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //stop recorder on stop click
                mediaRecorder.stop();

                //can't stop again
                StopRecording.setEnabled(false);

                //assume storage success
                PlayAudio.setEnabled(true);

                //can start a new recording once done with old
                StartRecording.setEnabled(true);

                //inform user of success
                Toast.makeText(MainActivity.this, "Recording Done",
                        Toast.LENGTH_LONG).show();
            }
        });

        PlayAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //don't allow recording while playing
                StopRecording.setEnabled(false);
                StartRecording.setEnabled(false);

                //necessary for closing storage
                StopPlayingAudio.setEnabled(true);

                //prepare player
                mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(AudioStorage);
                    mediaPlayer.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                mediaPlayer.start();

                //inform user of succcess
                Toast.makeText(MainActivity.this, "Recording Playing",
                        Toast.LENGTH_LONG).show();
            }
        });

        StopPlayingAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //allow writing to storage after storage is closed
                StartRecording.setEnabled(true);

                //only need one click to stop, should be enabled again if play audio is clicked again
                StopPlayingAudio.setEnabled(false);

                //user can play the same audio again if they wish, before recording again
                PlayAudio.setEnabled(true);

                //ensure that audio exists
                if(mediaPlayer != null){
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    RecorderReady();
                }
            }
        });

    }

    // fucntion for preparing the recorder
    public void RecorderReady(){
        mediaRecorder=new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        mediaRecorder.setOutputFile(AudioStorage);
    }

    //function for creating the save file
    public String MakeFileName(int string){
        StringBuilder myFileName = new StringBuilder( string );
        int i = 0 ;
        while(i < string ) {
            myFileName.append(AudioFile.
                    charAt(random.nextInt(AudioFile.length())));
            i++ ;
        }
        return myFileName.toString();
    }







}
